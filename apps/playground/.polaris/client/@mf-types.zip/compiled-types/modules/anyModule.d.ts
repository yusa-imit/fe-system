export default function Page(): import("react").JSX.Element;
//# sourceMappingURL=anyModule.d.ts.map